 TEMPLATE GENERATED TESTCASE FILE
Filename: CWE89_SQL_Injection__Environment_executeBatch_74a.java
Label Definition File: CWE89_SQL_Injection.label.xml
Template File: sources-sinks-74a.tmpl.java


  @description
  CWE: 89 SQL Injection
  BadSource: Environment Read data from an environment variable
  GoodSource: A hardcoded string
  Sinks: executeBatch
     GoodSink: Use prepared statement and executeBatch (properly)
     BadSink : data concatenated into SQL statement used in executeBatch(), which could result in SQL Injection
  Flow Variant: 74 Data flow: data passed in a HashMap from one method to another in different source files in the same package
 
  



 java.util.HashMap;



public class CWE89_SQL_Injection__Environment_executeBatch_74a extends AbstractTestCase
{
    public void bad() throws Throwable
    {
        String data;

         get environment variable ADD 
         POTENTIAL FLAW: Read data from an environment variable 
        data = System.getenv("ADD");

        HashMap<Integer,String> dataHashMap = new HashMap<Integer,String>();
        dataHashMap.put(0, data);
        dataHashMap.put(1, data);
        dataHashMap.put(2, data);
        (new CWE89_SQL_Injection__Environment_executeBatch_74b()).badSink(dataHashMap  );
    }

    public void good() throws Throwable
    {
        goodG2B();
        goodB2G();
    }

     goodG2B() - use GoodSource and BadSink 
    private void goodG2B() throws Throwable
    {
        String data;

         FIX: Use a hardcoded string 
        data = "foo";

        HashMap<Integer,String> dataHashMap = new HashMap<Integer,String>();
        dataHashMap.put(0, data);
        dataHashMap.put(1, data);
        dataHashMap.put(2, data);
        (new CWE89_SQL_Injection__Environment_executeBatch_74b()).goodG2BSink(dataHashMap  );
    }

     goodB2G() - use BadSource and GoodSink 
    private void goodB2G() throws Throwable
    {
        String data;

         get environment variable ADD 
         POTENTIAL FLAW: Read data from an environment variable 
        data = System.getenv("ADD");

        HashMap<Integer,String> dataHashMap = new HashMap<Integer,String>();
        dataHashMap.put(0, data);
        dataHashMap.put(1, data);
        dataHashMap.put(2, data);
        (new CWE89_SQL_Injection__Environment_executeBatch_74b()).goodB2GSink(dataHashMap  );
    }

     Below is the main(). It is only used when building this testcase on
      its own for testing or for building a binary to use in testing binary
      analysis tools. It is not used when compiling all the testcases as one
      application, which is how source code analysis tools are tested.
     
    public static void main(String[] args) throws ClassNotFoundException,
           InstantiationException, IllegalAccessException
    {
        mainFromParent(args);
    }
}
