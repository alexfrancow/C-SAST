 TEMPLATE GENERATED TESTCASE FILE
Filename: CWE89_SQL_Injection__Environment_executeUpdate_71a.java
Label Definition File: CWE89_SQL_Injection.label.xml
Template File: sources-sinks-71a.tmpl.java


  @description
  CWE: 89 SQL Injection
  BadSource: Environment Read data from an environment variable
  GoodSource: A hardcoded string
  Sinks: executeUpdate
     GoodSink: Use prepared statement and executeUpdate (properly)
     BadSink : data concatenated into SQL statement used in executeUpdate(), which could result in SQL Injection
  Flow Variant: 71 Data flow: data passed as an Object reference argument from one method to another in different classes in the same package
 
  






public class CWE89_SQL_Injection__Environment_executeUpdate_71a extends AbstractTestCase
{
    public void bad() throws Throwable
    {
        String data;

         get environment variable ADD 
         POTENTIAL FLAW: Read data from an environment variable 
        data = System.getenv("ADD");

        (new CWE89_SQL_Injection__Environment_executeUpdate_71b()).badSink((Object)data  );
    }

    public void good() throws Throwable
    {
        goodG2B();
        goodB2G();
    }

     goodG2B() - use goodsource and badsink 
    private void goodG2B() throws Throwable
    {
        String data;

         FIX: Use a hardcoded string 
        data = "foo";

        (new CWE89_SQL_Injection__Environment_executeUpdate_71b()).goodG2BSink((Object)data  );
    }

     goodB2G() - use badsource and goodsink 
    private void goodB2G() throws Throwable
    {
        String data;

         get environment variable ADD 
         POTENTIAL FLAW: Read data from an environment variable 
        data = System.getenv("ADD");

        (new CWE89_SQL_Injection__Environment_executeUpdate_71b()).goodB2GSink((Object)data  );
    }

     Below is the main(). It is only used when building this testcase on
      its own for testing or for building a binary to use in testing binary
      analysis tools. It is not used when compiling all the testcases as one
      application, which is how source code analysis tools are tested.
     
    public static void main(String[] args) throws ClassNotFoundException,
           InstantiationException, IllegalAccessException
    {
        mainFromParent(args);
    }
}
