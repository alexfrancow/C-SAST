 TEMPLATE GENERATED TESTCASE FILE
Filename: CWE89_SQL_Injection__Environment_prepareStatement_54a.java
Label Definition File: CWE89_SQL_Injection.label.xml
Template File: sources-sinks-54a.tmpl.java


  @description
  CWE: 89 SQL Injection
  BadSource: Environment Read data from an environment variable
  GoodSource: A hardcoded string
  Sinks: prepareStatement
     GoodSink: Use prepared statement and execute (properly)
     BadSink : data concatenated into SQL statement used in prepareStatement() call, which could result in SQL Injection
  Flow Variant: 54 Data flow: data passed as an argument from one method through three others to a fifth; all five functions are in different classes in the same package
 
  






public class CWE89_SQL_Injection__Environment_prepareStatement_54a extends AbstractTestCase
{
    public void bad() throws Throwable
    {
        String data;

         get environment variable ADD 
         POTENTIAL FLAW: Read data from an environment variable 
        data = System.getenv("ADD");

        (new CWE89_SQL_Injection__Environment_prepareStatement_54b()).badSink(data );
    }

    public void good() throws Throwable
    {
        goodG2B();
        goodB2G();
    }

     goodG2B() - use goodsource and badsink 
    private void goodG2B() throws Throwable
    {
        String data;

         FIX: Use a hardcoded string 
        data = "foo";

        (new CWE89_SQL_Injection__Environment_prepareStatement_54b()).goodG2BSink(data );
    }

     goodB2G() - use badsource and goodsink 
    private void goodB2G() throws Throwable
    {
        String data;

         get environment variable ADD 
         POTENTIAL FLAW: Read data from an environment variable 
        data = System.getenv("ADD");

        (new CWE89_SQL_Injection__Environment_prepareStatement_54b()).goodB2GSink(data );
    }

     Below is the main(). It is only used when building this testcase on
      its own for testing or for building a binary to use in testing binary
      analysis tools. It is not used when compiling all the testcases as one
      application, which is how source code analysis tools are tested.
     
    public static void main(String[] args) throws ClassNotFoundException,
           InstantiationException, IllegalAccessException
    {
        mainFromParent(args);
    }
}
